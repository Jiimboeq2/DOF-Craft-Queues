# DOF-Craft-Queues
C:\Program Files (x86)\InnerSpace\Scripts\EQ2Craft\Queues
